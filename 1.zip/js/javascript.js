window.onload = function(){
	$('buttonOrder').onclick = function(){
		//e.preventDefault();
		if(validateAll()){
			$('order').submit();
		} else {
			return false;
		}
		
	}; 
	
	$('buttonPrint').onclick = function(){
		location.href="index.php";
		readText();
	}; 
	
	$('inputPostalCode').onblur = function(){
		$('inputPostalCode').value = $('inputPostalCode').value.toUpperCase();
	};

}

var reader = new XMLHttpRequest() || new ActiveXObject('MSXML2.XMLHTTP');

function readText(){
    reader.open('get', 'receipt.txt', true); 
    reader.onreadystatechange = displayContents;
    reader.send(null);
}

function displayContents() {
    if(reader.readyState==4) {	
		var openWindow = window.open('receipt.html','_blank','width=400,height=600,resizable=yes');
		openWindow.document.write('<p>'+reader.responseText+'</p>');
    }
}